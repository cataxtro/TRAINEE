#!/usr/bin/env python3
#coding=utf-8

import rospy
from head_move.msg import head

def mexer_cabeca(visao_bola):
    pub = rospy.Publisher('publisher_cabeca', head, queue_size=10)
    rospy.init_node('talker_cabeca', anonymous=True)
    rate = rospy.Rate(1) # 1hz
    motor = head()
    for i in range(13):
        motor.id[i] = i+1
    while visao_bola == 0:
        for i in range(2):
            motor.torque[i] = True
            motor.vel[i] = 2
        j = -45
        while j<46:
            motor.pos[0] = j
            j = j+30
            k = -90
            while k<91:
                motor.pos[1] = k
                k = k+30
                print(motor)
    
    while not rospy.is_shutdown():
        #rospy.loginfo(motor)
        #print('Movimentando a cabeça: ID %d, Velocidade %.3f Motor %s, Posicao %.3f' % (motor.id[k],motor.vel[k],motor.torque[k],motor.pos[k]))
        pub.publish(motor)
        rate.sleep()

if __name__ == '__main__':
    try:
        teste = 0
        mexer_cabeca(teste)
    except rospy.ROSInterruptException:
        pass