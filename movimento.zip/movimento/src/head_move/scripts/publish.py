#!/usr/bin/env python3
# license removed for brevity
import rospy
import random
from head_move.msg import head

def teste():
    pub = rospy.Publisher('publisher_teste', head, queue_size=10)
    rospy.init_node('talker_teste', anonymous=True)
    rate = rospy.Rate(1) # 1hz
    msg = head()
    for i in range(13):
        msg.id[i] = i
        msg.pos[i] = random.random()
        msg.vel[i] = random.uniform(0,50)
        msg.torque[i] = random.choice([True,False])

    while not rospy.is_shutdown():
        #rospy.loginfo(msg)
        pub.publish(msg)
        rate.sleep()

if __name__ == '__main__':
    try:
        teste()
    except rospy.ROSInterruptException:
        pass