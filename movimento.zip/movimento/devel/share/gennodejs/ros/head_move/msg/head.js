// Auto-generated. Do not edit!

// (in-package head_move.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class head {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.pos = null;
      this.vel = null;
      this.torque = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = new Array(13).fill(0);
      }
      if (initObj.hasOwnProperty('pos')) {
        this.pos = initObj.pos
      }
      else {
        this.pos = new Array(13).fill(0);
      }
      if (initObj.hasOwnProperty('vel')) {
        this.vel = initObj.vel
      }
      else {
        this.vel = new Array(13).fill(0);
      }
      if (initObj.hasOwnProperty('torque')) {
        this.torque = initObj.torque
      }
      else {
        this.torque = new Array(13).fill(0);
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type head
    // Check that the constant length array field [id] has the right length
    if (obj.id.length !== 13) {
      throw new Error('Unable to serialize array field id - length must be 13')
    }
    // Serialize message field [id]
    bufferOffset = _arraySerializer.int16(obj.id, buffer, bufferOffset, 13);
    // Check that the constant length array field [pos] has the right length
    if (obj.pos.length !== 13) {
      throw new Error('Unable to serialize array field pos - length must be 13')
    }
    // Serialize message field [pos]
    bufferOffset = _arraySerializer.float64(obj.pos, buffer, bufferOffset, 13);
    // Check that the constant length array field [vel] has the right length
    if (obj.vel.length !== 13) {
      throw new Error('Unable to serialize array field vel - length must be 13')
    }
    // Serialize message field [vel]
    bufferOffset = _arraySerializer.float64(obj.vel, buffer, bufferOffset, 13);
    // Check that the constant length array field [torque] has the right length
    if (obj.torque.length !== 13) {
      throw new Error('Unable to serialize array field torque - length must be 13')
    }
    // Serialize message field [torque]
    bufferOffset = _arraySerializer.bool(obj.torque, buffer, bufferOffset, 13);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type head
    let len;
    let data = new head(null);
    // Deserialize message field [id]
    data.id = _arrayDeserializer.int16(buffer, bufferOffset, 13)
    // Deserialize message field [pos]
    data.pos = _arrayDeserializer.float64(buffer, bufferOffset, 13)
    // Deserialize message field [vel]
    data.vel = _arrayDeserializer.float64(buffer, bufferOffset, 13)
    // Deserialize message field [torque]
    data.torque = _arrayDeserializer.bool(buffer, bufferOffset, 13)
    return data;
  }

  static getMessageSize(object) {
    return 247;
  }

  static datatype() {
    // Returns string type for a message object
    return 'head_move/head';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b247c1f6305662e2daa7a135df473de9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16[13] id
    float64[13] pos
    float64[13] vel
    bool[13] torque
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new head(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = new Array(13).fill(0)
    }

    if (msg.pos !== undefined) {
      resolved.pos = msg.pos;
    }
    else {
      resolved.pos = new Array(13).fill(0)
    }

    if (msg.vel !== undefined) {
      resolved.vel = msg.vel;
    }
    else {
      resolved.vel = new Array(13).fill(0)
    }

    if (msg.torque !== undefined) {
      resolved.torque = msg.torque;
    }
    else {
      resolved.torque = new Array(13).fill(0)
    }

    return resolved;
    }
};

module.exports = head;
