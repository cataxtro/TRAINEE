
"use strict";

let head = require('./head.js');

module.exports = {
  head: head,
};
